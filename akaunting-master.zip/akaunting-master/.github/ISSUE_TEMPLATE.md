Please, submit only real issues. Use the forum for support, feature requests, proposals, new versions, help etc. https://akaunting.com/forum

### Steps to reproduce the issue



### Expected result



### Actual result



### System information (Akaunting, PHP versions)



### Additional comments


