<?php

namespace App\Interfaces\Listener;

interface ShouldUpdateAllCompanies
{
    //
}
