<?php

namespace App\Interfaces\Job;

interface HasSource
{
    //
}
